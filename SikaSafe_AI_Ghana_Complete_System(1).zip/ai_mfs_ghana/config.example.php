<?php
return [
  'app_name' => 'SikaSafe AI Ghana',
  'base_url' => 'https://your-subdomain.infinityfreeapp.com',
  'db_host' => 'sqlXXX.infinityfree.com',
  'db_name' => 'if0_XXXXXXXX_sikasafe',
  'db_user' => 'if0_XXXXXXXX',
  'db_pass' => 'CHANGE_ME',
  'email_from' => 'no-reply@yourdomain.com',
  'demo_mode' => true
];
