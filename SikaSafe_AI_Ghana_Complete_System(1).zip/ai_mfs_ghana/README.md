# SikaSafe AI Ghana

An InfinityFree-compatible PHP/MySQL system for explainable mobile-financial-service safety checks in Ghana.

## Main features

- Secure account registration and login
- Live camera capture or JPG/PNG/WebP profile upload
- Email and Ghana phone-number fields with verification-ready database tables
- Permission-based browser geolocation and Google Maps link
- Explainable rule-based AI risk score for suspicious transactions
- Incident reporting with evidence upload
- QR code for the deployed dashboard link
- CSRF protection, password hashing, prepared SQL, secure session cookies, upload validation and role-ready accounts

## Install on XAMPP

1. Copy the folder into `C:\xampp\htdocs\sikasafe`.
2. Create a MySQL database named `sikasafe` and import `database/schema.sql` in phpMyAdmin.
3. Copy `config.example.php` to `config.php` and enter local database details. For standard XAMPP these are usually host `localhost`, user `root`, blank password.
4. Open `http://localhost/sikasafe/`.

## Install on InfinityFree

1. Create an InfinityFree hosting account and MySQL database.
2. Open the online File Manager and upload the contents of this folder into `htdocs`.
3. Import `database/schema.sql` using the hosting phpMyAdmin.
4. Rename `config.example.php` to `config.php` and insert the exact MySQL hostname, database name, username and password shown in the control panel.
5. Set `base_url` to your public HTTPS address.
6. Ensure `uploads/profile` and `uploads/evidence` exist and are writable.

## GitHub

The source can be stored on GitHub, but GitHub Pages cannot execute PHP or MySQL. Use GitHub as the code repository and InfinityFree as the live PHP host. Never commit `config.php`.

## Production notes

- Email/SMS verification requires a transactional email/SMS provider. The included `verification_codes` table supports OTP implementation, but real delivery credentials are intentionally not embedded.
- Browser camera and geolocation normally require HTTPS on a public host.
- Risk scores provide safety guidance and must not be represented as guaranteed fraud detection.
