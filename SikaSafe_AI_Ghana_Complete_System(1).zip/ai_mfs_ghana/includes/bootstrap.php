<?php
declare(strict_types=1);
session_start([
  'cookie_httponly' => true,
  'cookie_samesite' => 'Lax',
  'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'
]);
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");
$configFile = __DIR__ . '/../config.php';
$config = file_exists($configFile) ? require $configFile : require __DIR__ . '/../config.example.php';
function db(): PDO {
  static $pdo;
  global $config;
  if (!$pdo) {
    $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4";
    $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false
    ]);
  }
  return $pdo;
}
function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function verify_csrf(): void {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Security token expired. Please go back and try again.'); }
}
function user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!user()) { header('Location: index.php?page=login'); exit; } }
function flash(string $type, string $text): void { $_SESSION['flash'] = [$type, $text]; }
function pull_flash(): ?array { $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function upload_image(string $field, string $folder): ?string {
  if (empty($_FILES[$field]['tmp_name'])) return null;
  if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK || $_FILES[$field]['size'] > 3*1024*1024) throw new RuntimeException('Image must be JPG, PNG or WebP and not more than 3 MB.');
  $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$field]['tmp_name']);
  $ext = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime] ?? null;
  if (!$ext) throw new RuntimeException('Unsupported image type.');
  $name = bin2hex(random_bytes(16)).'.'.$ext;
  $target = __DIR__.'/../uploads/'.$folder.'/'.$name;
  if (!move_uploaded_file($_FILES[$field]['tmp_name'], $target)) throw new RuntimeException('Image upload failed.');
  return 'uploads/'.$folder.'/'.$name;
}
function risk_score(array $d): array {
  $score=0; $reasons=[];
  $amount=(float)($d['amount']??0);
  if ($amount>=5000) { $score+=30; $reasons[]='Unusually high transaction amount'; }
  elseif ($amount>=1000) { $score+=15; $reasons[]='Elevated transaction amount'; }
  if (!empty($d['unknown_recipient'])) { $score+=25; $reasons[]='Recipient is not personally known'; }
  if (!empty($d['urgent_pressure'])) { $score+=25; $reasons[]='Urgency or pressure language reported'; }
  if (!empty($d['requested_pin'])) { $score+=40; $reasons[]='PIN or OTP was requested'; }
  if (!empty($d['suspicious_link'])) { $score+=30; $reasons[]='Untrusted link involved'; }
  if (!empty($d['new_device'])) { $score+=10; $reasons[]='New device or location'; }
  $score=min(100,$score); $level=$score>=70?'High':($score>=35?'Medium':'Low');
  return [$score,$level,$reasons ?: ['No strong risk indicators selected']];
}
