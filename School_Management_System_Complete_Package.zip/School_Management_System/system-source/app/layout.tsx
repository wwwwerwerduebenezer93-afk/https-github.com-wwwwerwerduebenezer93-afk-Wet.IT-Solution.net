import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aseda School Management System",
  description: "A unified portal for student records, attendance, assessment, fees and administration.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
